def add(a, b):
    """Retourne la somme de a et b."""
    return a + b


def subtract(a, b):
    """Retourne la différence entre a et b."""
    return a - b
